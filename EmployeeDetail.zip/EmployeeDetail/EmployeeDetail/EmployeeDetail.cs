﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeDetail
{
    public class EmployeeDetail
    {
        #region Class Members
        /// <summary>
        /// Members
        /// </summary>
        private int _employeeId;
        private string _employeeName;
        private double _salary;
        #endregion

        #region Properties
        /// <summary>
        /// Get or set the Id of employee
        /// </summary>
        public int EmployeeId
        {
            get
            {
                return _employeeId;
            }
            set
            {
                _employeeId = value;
            }
        }

        /// <summary>
        /// Get or set the Employee Name
        /// </summary>
        public string EmployeeName
        {
            get
            {
                return _employeeName;
            }
            set
            {
                _employeeName = value;
            }
        }

        /// <summary>
        /// Get or set the Salary of Employee
        /// </summary>
        public double Salary
        {
            get
            {
                return _salary;
            }
            set
            {
                _salary = value;
            }
        }
        #endregion

        #region Constructor
        /// <summary>
        /// Default Constructor
        /// </summary>
        public EmployeeDetail()
        {
        }
        #endregion

        #region Methods
        /// <summary>
        /// Access Modifiers:
        /// private
        /// public
        /// internal
        /// protected
        /// protected internal
        /// </summary>
        public string GetEmployeeName()
        {
            EmployeeDetail employee = new EmployeeDetail();
            employee.EmployeeId = 1;
            employee.EmployeeName = "Derek";
            employee.Salary = 10000;
            return employee.EmployeeName;
        }
        #endregion
    }
}
